﻿/*
 Copyright (c) 2003-2017, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("uicolor","pt",{title:"Seleção de Cor da IU",options:"Color Options",highlight:"Highlight",selected:"Selected Color",predefined:"Conjuntos de cor predefinidos",config:"Colar este item no seu ficheiro config.js"});